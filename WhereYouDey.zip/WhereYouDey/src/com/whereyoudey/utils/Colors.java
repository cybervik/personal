/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.whereyoudey.utils;

/**
 *
 * @author Vikram S
 */
public class Colors {

    public static final int BLACK = 0x000000;
    public static final int WHITE = 0xffffff;
    public static final int SELECTEDITEM_BACKGROUND = 0x9999ff;
    public static final int ADVERTISEMENT_BACKGROUND = 0xffa500;
    public static final int FORM_BACKGROUND = 15987699;
}
