package com.whereyoudey.webservice;

public class ArrayOfString {

    private String[] string;

    public void setString( String[] string ) {
        this.string = string;
    }

    public String[] getString() {
        return string;
    }

}
