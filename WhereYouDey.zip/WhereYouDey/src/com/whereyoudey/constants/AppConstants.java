/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.whereyoudey.constants;

/**
 *
 * @author Vikram S
 */
public class AppConstants {
    public static final int ICON_WIDTH = 20;
}
